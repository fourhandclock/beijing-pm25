"""Build the academic report and presentation from generated analysis tables.

No fitting or model selection occurs here. One content definition drives each
document's editable and PDF versions. Optional dependencies are pinned in
requirements-submission.lock; the scientific lock remains unchanged.
"""

import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mplconfig"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from PIL import Image as PILImage
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.util import Pt
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (Image, PageBreak, Paragraph, SimpleDocTemplate,
                               Spacer, Table, TableStyle)


OUT = ROOT / "submission"
FIG = OUT / "figures"
TITLE = "Beyond R²: Seasonal Effects, Residual Dependence, and Model Adequacy in Beijing PM2.5 Regression"
DEADLINE = "24 November 2026"
NAVY, TEAL, AMBER, INK, MUTED, PALE = "15324D", "087F8C", "B76B15", "233747", "536779", "EDF3F6"
AI = ("AI assistance: OpenAI Codex and Anthropic Claude assisted code and drafting; "
      "Codex assisted final verification and document preparation. Numerical claims "
      "are linked to generated tables and separate implementation checks. These "
      "checks are not independent scientific replication. The submitter remains "
      "responsible for interpretation and compliance with course policy.")
REFS = [
    ("Chen, S. (2017). Beijing Multi-Site Air Quality [Dataset]. UCI Machine Learning Repository. CC BY 4.0.",
     "https://doi.org/10.24432/C5RK5G"),
    ("Duan, N. (1983). Smearing Estimate: A Nonparametric Retransformation Method. Journal of the American Statistical Association, 78(383), 605–610.",
     "https://doi.org/10.1080/01621459.1983.10478017"),
    ("Statsmodels documentation: nested F comparisons, HAC covariance and iterative GLSAR. Method references; empirical results are from this project.",
     "https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.RegressionResults.compare_f_test.html"),
    ("UCI dataset documentation: station coverage, variables and weather matching.",
     "https://archive.ics.uci.edu/dataset/501/beijing+multi+site+air+quality+data"),
]
INPUTS, CLAIMS, FRAMES = {}, {}, {}
S2 = "results/stage2/tables/"
S3 = "results/stage3/tables/"
S4 = "results/stage4/tables/"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(name):
    INPUTS[name] = sha(ROOT / name)
    return ROOT / name


def frame(name):
    if name not in FRAMES:
        FRAMES[name] = pd.read_csv(source(name))
    return FRAMES[name]


def number(name, column, where, fmt=".3f"):
    data = frame(name)
    selected = pd.Series(True, index=data.index)
    for key, value in where.items():
        selected &= data[key].eq(value)
    if selected.sum() != 1:
        raise ValueError(f"A document claim must identify one row: {name}, {where}")
    value = float(data.loc[selected, column].iloc[0])
    if not np.isfinite(value):
        raise ValueError(f"Nonfinite document claim: {name}/{column}")
    key = json.dumps([name, column, where, fmt], sort_keys=True)
    CLAIMS[key] = {"source": name, "column": column, "where": where,
                   "value": value, "format": fmt, "display": format(value, fmt)}
    return format(value, fmt)


def score(model="M3", column="mae", split="test", group="all", fmt=".3f", stage=2):
    return number((S2+"performance.csv") if stage == 2 else (S3+"model_comparison_scores.csv"),
                  column, {"split": split, "model": model, "subgroup": group}, fmt)


def logit(column, fmt=".3f"):
    return number(S3+"smog_logistic_performance.csv", column,
                  {"split": "test", "cutoff_rule": "validation_max_f1"}, fmt)


def figures():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 14,
                         "axes.labelsize": 15, "axes.titlesize": 17,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.prop_cycle": plt.cycler(color=["#"+TEAL, "#"+AMBER, "#"+NAVY]),
                         "figure.dpi": 170, "savefig.facecolor": "white"})

    def save(fig, name):
        fig.savefig(FIG / (name+".png"), dpi=180, bbox_inches="tight")
        plt.close(fig)

    acf = frame(S2+"training_residual_acf.csv").query("model == 'M3'")
    fig, ax = plt.subplots(figsize=(10, 4.1), layout="constrained")
    ax.vlines(acf.lag_days, 0, acf.correlation, linewidth=3, color="#"+TEAL)
    ax.scatter(acf.lag_days, acf.correlation, color="#"+TEAL, s=32)
    ax.axhline(0, color="#"+MUTED, linewidth=0.8)
    ax.set(xlabel="Calendar lag (days)", ylabel="Paired-day residual correlation",
           title="M3 retains substantial day-to-day residual dependence", ylim=(-0.18, 0.6))
    ax.text(0.98, 0.88, f"Lag 1: r = {number(S2+'training_residual_acf.csv', 'correlation', {'model':'M3','lag_days':1})}\n"
            f"{number(S2+'training_residual_acf.csv', 'paired_days', {'model':'M3','lag_days':1}, '.0f')} observed date pairs",
            transform=ax.transAxes, ha="right", color="#"+NAVY)
    save(fig, "residual_dependence")

    residuals = frame(S2+"training_influence.csv").query("model == 'M3'")
    fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.5), layout="constrained")
    axes[0].scatter(residuals.fitted, residuals.residual, s=14, alpha=0.5, color="#"+TEAL)
    axes[0].axhline(0, color="#"+MUTED, linewidth=1)
    axes[0].set(xlabel="Fitted PM2.5 (µg/m³)", ylabel="Residual (µg/m³)", title="Unequal spread and large positive errors")
    (theory, ordered), (slope, intercept, _) = stats.probplot(residuals.residual)
    axes[1].scatter(theory, ordered, s=14, color="#"+TEAL, alpha=0.7)
    axes[1].plot(theory, intercept+slope*theory, color="#"+AMBER)
    axes[1].set(xlabel="Normal theoretical quantile", ylabel="Ordered residual (µg/m³)", title="Normal Q–Q: upper-tail departure")
    save(fig, "residual_shape")

    predictions = frame(S2+"predictions.csv").query("split == 'test' and model == 'M3'").copy()
    predictions.index = pd.to_datetime(predictions.date)
    predictions = predictions.reindex(pd.date_range("2016-03-01", "2017-02-28"))
    fig, ax = plt.subplots(figsize=(10.5, 4.1), layout="constrained")
    ax.plot(predictions.index, predictions.observed, label="Observed", color="#"+NAVY, lw=1.2)
    ax.plot(predictions.index, predictions.predicted, label="Frozen M3 estimate", color="#"+TEAL, lw=1.2)
    ax.axhline(0, color="#"+MUTED, lw=0.5)
    ax.set(ylabel="Daily PM2.5 (µg/m³)", xlabel="Test dates, March 2016–February 2017",
           title="A lower average error still leaves severe high-day underestimation")
    ax.legend(frameon=False, loc="upper left", ncol=2, fontsize=12)
    save(fig, "frozen_test")

    models = ["M3", "M3_log", "M3_lag", "M3_met", "M3_log_lag_met"]
    labels = ["M3 refit", "Log M3", "+ Previous-day PM2.5", "+ Extra weather", "Log + lag + extra weather"]
    data = frame(S3+"model_comparison_scores.csv")
    fig, ax = plt.subplots(figsize=(10, 4.8), layout="constrained")
    for offset, split, label, color in [(-0.18, "validation", "Validation (n=354)", TEAL),
                                        (0.18, "test", "Reused test year (n=355)", AMBER)]:
        values = [data.loc[data.model.eq(m)&data.split.eq(split)&data.subgroup.eq("all"), "mae"].iloc[0] for m in models]
        bars = ax.barh(np.arange(5)+offset, values, height=0.33, label=label, color="#"+color)
        ax.bar_label(bars, fmt="%.1f", padding=4, fontsize=12)
    ax.set_yticks(np.arange(5), labels)
    ax.invert_yaxis()
    ax.set(xlabel="MAE on the original concentration scale (µg/m³)", xlim=(0, 61),
           title="Exploratory comparisons use one common sample")
    ax.legend(frameon=False, loc="lower right", fontsize=11)
    save(fig, "extension_mae")

    stations = frame(S3+"station_replication.csv").sort_values("m2_wind_coefficient")
    fig, ax = plt.subplots(figsize=(10, 5.2), layout="constrained")
    x = stations.m2_wind_coefficient
    ax.errorbar(x, np.arange(12), xerr=[x-stations.m2_wind_hac_ci_lower, stations.m2_wind_hac_ci_upper-x],
                fmt="o", color="#"+TEAL, capsize=3)
    ax.set_yticks(np.arange(12), stations.station)
    ax.axvline(0, color="#"+MUTED, lw=1)
    ax.set(xlabel="M2 wind association (µg/m³ per m/s), individual 95% HAC interval",
           title="Negative adjusted wind associations at all 12 stations")
    save(fig, "station_wind")

    clusters = frame(S3+"station_clusters.csv").sort_values(["cluster", "pm25"])
    pollutants = ["pm25", "pm10", "so2", "no2", "co", "o3"]
    fig, ax = plt.subplots(figsize=(9, 5.6), layout="constrained")
    im = ax.imshow(clusters[[p+"_z" for p in pollutants]], aspect="auto", cmap="RdBu_r", vmin=-2.5, vmax=2.5)
    ax.set_xticks(range(6), ["PM2.5", "PM10", "SO₂", "NO₂", "CO", "O₃"])
    ax.set_yticks(range(12), [f"{r.station}  [{r.cluster}]" for r in clusters.itertuples()])
    ax.axhline(3.5, color="white", lw=3)
    ax.set_title("Training pollutant profiles; bracketed values are cluster labels")
    fig.colorbar(im, ax=ax, label="Across-station z-score (sample SD)", shrink=0.9)
    save(fig, "station_profiles")

    slopes = frame(S2+"m3_seasonal_wind_slopes.csv")
    # Read the named columns rather than computing new coefficient intervals.
    xcol = "pm25_change_per_1_mps_wind"
    low = "hac_ci_lower"
    high = "hac_ci_upper"
    fig, ax = plt.subplots(figsize=(10, 3.7), layout="constrained")
    x = slopes[xcol]
    ax.errorbar(x, range(4), xerr=[x-slopes[low], slopes[high]-x], fmt="o", color="#"+TEAL, capsize=4)
    ax.set_yticks(range(4), slopes.season.str.capitalize())
    ax.axvline(0, color="#"+MUTED, lw=1)
    ax.set(xlabel="M3 wind slope (µg/m³ per m/s), individual 95% HAC interval",
           title="The summer interval includes zero; joint evidence is weaker after adjustment")
    save(fig, "seasonal_wind")


def content():
    """Canonical prose/tables and slide content; all empirical numbers read files."""
    frozen = json.loads(source("results/stage2/frozen_model.json").read_text())
    source("results/stage1_run.json")
    source("results/stage2/run.json")
    source("results/stage3/run.json")
    source("reports/stage4/statistical_audit.md")
    source("data/raw/provenance.json")
    ntrain = str(frozen["training_observations"])
    nval = str(frozen["validation_observations"])
    ntest = score(column="n", fmt=".0f")
    cutoff = f"{frozen['high_pollution_training_cutoff']:.3f}"
    rho = number(S2+"training_residual_acf.csv", "correlation", {"model":"M3", "lag_days":1})
    r2 = number(S2+"model_fit.csv", "r_squared", {"model":"M3"})
    hp = number(S2+"hac_joint_tests.csv", "p_holm_primary", {"hypothesis":"H1_season", "hac_lag_calendar_days":7}, ".4f")

    def p(text): return {"kind":"p", "text":text}
    def h(text): return {"kind":"h", "text":text}
    def image(name, caption): return {"kind":"image", "name":name, "caption":caption}
    def table(headers, rows): return {"kind":"table", "headers":headers, "rows":rows}

    fit_rows = [[m, number(S2+"model_fit.csv", "parameters", {"model":m}, ".0f"),
                 number(S2+"model_fit.csv", "r_squared", {"model":m}),
                 number(S2+"model_fit.csv", "adjusted_r_squared", {"model":m}),
                 number(S2+"model_fit.csv", "sse", {"model":m}, ".1f")] for m in ("M1", "M2", "M3")]
    tests = []
    for hypothesis, label in [("H1_season", "H1: add season"), ("H2_wind_by_season", "H2: wind × season")]:
        tests.append([label, number(S2+"nested_anova.csv", "f_statistic", {"hypothesis":hypothesis}),
                      number(S2+"nested_anova.csv", "p_value_iid", {"hypothesis":hypothesis}, ".4f"),
                      number(S2+"hac_joint_tests.csv", "p_value_hac", {"hypothesis":hypothesis,"hac_lag_calendar_days":7}, ".4f"),
                      number(S2+"hac_joint_tests.csv", "p_holm_primary", {"hypothesis":hypothesis,"hac_lag_calendar_days":7}, ".4f")])
    coefficients = []
    for term, label in [("temperature_c","Temperature (°C)"), ("wind_speed_c","Wind (m/s)"),
                        ("rainfall_c","Rain (mm/day)"), ("pressure_c","Pressure (hPa)")]:
        coefficients.append([label, number(S2+"coefficients.csv","estimate",{"model":"M2","term":term}),
                             "["+number(S2+"coefficients.csv","hac_ci_lower",{"model":"M2","term":term})+", "+
                             number(S2+"coefficients.csv","hac_ci_upper",{"model":"M2","term":term})+"]"])
    validation = [[m, number(S2+"validation_selection.csv", "mae", {"model":m}),
                   number(S2+"validation_selection.csv", "rmse", {"model":m})] for m in ("M1","M2","M3")]
    errors = [["M3", score(), score(column="rmse"), score(column="mean_signed_error")],
              ["Training mean", score("training_mean"), score("training_mean","rmse"), score("training_mean","mean_signed_error")],
              ["M3: high days only", score(group="high"), score(column="rmse",group="high"), score(column="mean_signed_error",group="high")]]
    ext_names = [("M3","M3 refit"),("M3_log","Log M3"),("M3_lag","M3 + prior PM2.5"),
                 ("M3_met","M3 + extra weather"),("M3_log_lag_met","Log + lag + weather")]
    extensions = [[label, score(m, split="validation", fmt=".1f", stage=3), score(m, fmt=".1f", stage=3),
                   score(m,column="rmse",fmt=".1f",stage=3)] for m,label in ext_names]
    ar_rows = []
    for method,label in [("original_glsar_rows","Original GLSAR rows"),("conditional_ml_rows","Likelihood rows"),
                          ("conditional_ml_calendar","Likelihood calendar")]:
        ar_rows.append([label, number(S4+"ar1_calendar_sensitivity.csv","rho",{"method":method,"model":"M2"}),
                        number(S4+"ar1_calendar_sensitivity.csv","p_value_approx",{"method":method,"model":"M2"},".4f"),
                        number(S4+"ar1_calendar_sensitivity.csv","p_value_approx",{"method":method,"model":"M3"},".4f")])
    stations = frame(S3+"station_replication.csv")
    h1 = int(stations.h1_holm_p.lt(.05).sum())
    h2 = int(stations.h2_holm_p.lt(.05).sum())
    wins = int(stations.test_m3_mae.lt(stations.test_baseline_mae).sum())
    groups = frame(S3+"station_clusters.csv")
    group1 = ", ".join(groups.loc[groups.cluster.eq(1),"station"].sort_values())
    group2 = ", ".join(groups.loc[groups.cluster.eq(2),"station"].sort_values())

    pages = [
        {"title":"Abstract and research question", "blocks":[
            p("Daily pollution regression can explain an average pattern while leaving errors that undermine conventional inference and practical use. This investigation asks whether seasonal indicators and season-specific wind associations add information beyond observed weather, and whether residual diagnostics support the adequacy of the resulting multiple regressions."),
            p(f"The UCI Beijing Multi-Site Air Quality dataset supplies hourly records at 12 stations. Wanliu is selected using training-period completeness. Three nested original-scale models are fitted on {ntrain} training days; {nval} validation days select a specification by a fixed rule, followed by a frozen {ntest}-day test evaluation. Classical nested-model ANOVA is accompanied by calendar-aware HAC joint tests and the prespecified Holm correction."),
            p(f"Validation selects M3, with training R² {r2} and test MAE {score()} µg/m³, versus {score('training_mean')} for the training-mean baseline. Both primary joint tests have Holm-adjusted p = {hp}, so neither rejects at 5%. Residual lag-one correlation is {rho}; severe high-day underestimation and negative estimates expose limitations that R² alone does not describe."),
            p("Later log/lag/weather alternatives, an AR(1) sensitivity analysis, cross-station comparisons, classification and clustering are exploratory. They were developed after the original test year had been inspected. Their numerical improvements motivate future study; they are not fresh confirmatory evidence. Every model uses actual same-day weather and therefore estimates contemporaneous concentrations rather than producing genuine advance forecasts."),
            h("Scope of the evidence"),
            table(["Analysis","Role","Evaluation status"], [["Stage 2","Prespecified core regression","Original frozen test retained"],
                    ["Stage 3","Exploratory extensions","Previously viewed test year"],["Stage 4","Verification and sensitivity","No new confirmatory period"]]),
            p("Keywords: multiple regression; nested-model ANOVA; HAC covariance; residual dependence; model adequacy; PM2.5.")
        ]},
        {"title":"1. Data, preprocessing and evaluation design", "blocks":[
            p("Chen's UCI dataset contains 420,768 hourly station records from March 2013 through February 2017 at 12 Beijing sites. Weather observations are matched from nearby weather stations. The original archive is preserved unchanged and identified by its committed SHA-256 checksum. Data are attributed to Chen (2017), UCI, under CC BY 4.0 [1,4]."),
            p("Station selection is based only on eligible training-day count, then valid training PM2.5-hour count, then alphabetical name. Wanliu ranks first. The analysis preserves a complete 1,461-day calendar, keeping unavailable dates explicit. It rejects duplicate/malformed timestamps and mixed station labels; invalid physical measurements are masked and counted. Valid zeros, negative temperatures and high positive pollution readings are retained."),
            p("Daily PM2.5, temperature, pressure and wind-speed means each require 18 valid hours. Rain totals require all 24 hourly amounts, and an analysis day needs 18 hours with all five core fields jointly observed. Means use each variable's own valid hours. Missing outcomes are neither imputed nor treated as zero. Completeness exclusions can be selective, so retaining many dates is not proof of representativeness."),
            table(["Partition","Dates (end exclusive)","Retained / calendar days"],
                  [["Training","2013-03-01 to 2015-03-01",ntrain+" / 730"],
                   ["Validation","2015-03-01 to 2016-03-01",nval+" / 366"],
                   ["Test","2016-03-01 to 2017-03-01",ntest+" / 365"]]),
            p("The 1,441 eligible days exclude 20 calendar dates. Timestamps are treated as local civil dates, assumed Asia/Shanghai because the source does not explicitly specify a timezone. Summing rainfall assumes the source entries are hourly interval amounts. These are documented measurement assumptions, not verified instrument specifications."),
            p("All centering constants, training means and high-day thresholds use training data only. Validation MAE is used for model selection; final test responses do not enter that rule. The high-day cutoff is the eligible training daily 95th percentile, "+cutoff+" µg/m³, distinct from any hourly threshold or regulatory category. Chronological splitting reduces direct future-to-past leakage but does not remove dependence or distribution shifts.")
        ]},
        {"title":"2. Multiple regression and planned hypotheses", "blocks":[
            p("Let Y be daily PM2.5 in µg/m³, and T, W, R and P be centered daily temperature, wind speed, rainfall and pressure. Winter is the reference season, with three indicators S for spring, summer and autumn. Centering uses training means and changes interpretation, not the fitted model family."),
            p("M1: E(Y | X) = β₀ + βT T + βW W + βR R + βP P. M2 adds Σ γs Ss. M3 additionally adds Σ δs (W × Ss). The models have 5, 8 and 11 parameters. Each training design is full rank; numerical conditioning is checked separately from statistical uncertainty."),
            table(["Model","Parameters","R²","Adjusted R²","SSE"],fit_rows),
            p("H1 tests whether the three seasonal coefficients in M2 are jointly zero after weather adjustment (M1 versus M2). H2 tests whether the three wind-by-season coefficients in M3 are jointly zero (M2 versus M3). Under M3, seasonal offsets apply at the training mean wind speed; its base wind coefficient is the winter slope. Joint tests are the planned inferential questions, rather than a search among individual coefficient p-values."),
            p("Nested-model ANOVA uses F = [(SSErestricted − SSEfull) / q] / [SSEfull / (n − pfull)], with q = 3 added parameters in each comparison. The exact F reference requires an appropriate linear mean and independent, homoscedastic Gaussian errors. The ordinary calculation is informative about fit reduction, but its nominal significance is vulnerable when diagnostics reveal dependence or unequal variance [3]."),
            table(["Question","F","Classical p","7-day HAC p","Primary Holm p"], tests),
            p("For primary inference, Bartlett-weight calendar HAC estimates covariance using observed score products at actual date separations, with unavailable daily positions contributing zero scores. The n/(n−p) correction is applied. A 7-day bandwidth is primary; 14/30-day values are descriptive sensitivities. Wald joint statistics use an asymptotic χ²(3) reference. Holm correction covers the two prespecified primary hypotheses. Neither rejects at α = 0.05; this is insufficient evidence against those nulls, not proof of no seasonal structure. HAC cannot correct an inadequate mean, informative missingness or omitted confounding.")
        ]},
        {"title":"3. Conditional interpretation of coefficients", "blocks":[
            table(["M2 predictor (one unit)","Estimated difference (µg/m³)","Individual 95% HAC interval"],coefficients),
            p("A weather coefficient describes the fitted concentration difference associated with one additional unit, conditional on the other listed predictors and season. For example, M2's wind coefficient is "+coefficients[1][1]+" µg/m³ per m/s, with interval "+coefficients[1][2]+". It is an adjusted observational association. It does not estimate the effect of artificially increasing wind or identify the mechanism producing pollution."),
            p("The four seasonal wind slopes in M3 combine the base coefficient and its interaction. Their intervals use the full contrast covariance, including covariance between those terms. The intervals are individual rather than simultaneous; a negative point estimate for summer does not establish a nonzero summer association when its interval includes zero."),
            image("seasonal_wind","Figure 1. Training M3 wind associations with individual 7-calendar-day HAC intervals. Source: m3_seasonal_wind_slopes.csv."),
            p("Temperature, pressure and season are related. Their conditional coefficients should not be equated with marginal correlations or simple seasonal mean differences. A nonsignificant contrast does not demonstrate equality, and a narrow individual interval does not rescue misspecified errors. The primary joint-test conclusion remains governed by the prespecified two-test adjustment.")
        ]},
        {"title":"4. Residual diagnostics: adequacy beyond R²", "blocks":[
            p(f"Training R² rises only from {fit_rows[0][2]} to {r2}. More importantly, M3 residuals retain a lag-one paired-calendar correlation of {rho}. Calendar-aware plots retain missing daily positions; consecutive retained rows are not automatically treated as consecutive days. The remaining structure suggests that the weather-and-season mean is incomplete."),
            image("residual_dependence","Figure 2. Calendar-lag training residual correlations for M3. Pair counts vary by lag; no iid confidence band is asserted."),
            image("residual_shape","Figure 3. Training residual-versus-fitted and normal Q–Q plots. Upper-tail departures and changing spread warrant caution about Gaussian/iid calibration."),
            p("The serial auxiliary regression uses the preceding seven calendar-day residuals, retaining only rows with all auxiliary lags. Its diagnostic p-value is approximate. Breusch–Pagan/Koenker, Jarque–Bera and influence checks also require assumptions; their small nominal p-values are supporting evidence, not an independence certificate. Forty M3 observations exceed the Cook's-distance 4/n screening guide; none is deleted. A Q–Q plot concerns distributional shape, not temporal independence.")
        ]},
        {"title":"5. Validation choice and the frozen test year", "blocks":[
            table(["Candidate","Validation MAE","Validation RMSE"],validation),
            p("The unchanged rule minimizes validation MAE, preferring fewer parameters among models within 1% of the minimum. It chooses M3. M2 is only 1.11% worse than the minimum, just outside that tolerance: this small difference should not be portrayed as decisive superiority. Inference p-values and test errors do not select the model. Coefficients, centers, baseline and high-day cutoff are persisted before final scoring, with no validation/test refit and no clipping."),
            table(["Test evaluation","MAE","RMSE","Mean estimate − observation"],errors),
            p(f"Errors are in µg/m³. The overall comparison uses {ntest} eligible dates. The high-day M3 row uses only {score(column='n',group='high',fmt='.0f')} days at or above the training cutoff. Overall bias is positive, but high-day bias is negative: aggregation conceals a different error direction during severe episodes. The selected model has {score(column='negative_predictions',fmt='.0f')} negative test estimates, retained as evidence of a physical limitation of unrestricted linear regression."),
            image("frozen_test","Figure 4. Frozen Stage 2 test estimates using observed same-day weather. Missing dates break lines; the graph is descriptive after selection."),
            p("These are held-out contemporaneous estimates, not advance forecasts. Dependence makes naive independent-day confidence intervals for error differences inappropriate; none is claimed. Reproducing the frozen evaluation verifies the computation but cannot restore the original test year's unseen status.")
        ]},
        {"title":"6. Exploratory improvements and AR(1) sensitivity", "blocks":[
            p("Stage 3 adds a log1p response, prior-calendar-day PM2.5, and extra weather (dew point and two wind-vector components). All five candidates use the same 721 training, 354 validation and 355 test dates. Their M3 is a refit on this common sample, not the frozen Stage 2 evaluation. The slightly changed sample also changes its training high-day cutoff."),
            table(["Common-sample model","Validation MAE","Test MAE*","Test RMSE*"],extensions),
            p("*The test year was already viewed before Stage 3, so its scores are descriptive. The combined candidate is selected by validation MAE within this exploratory set. Its errors are smaller on these dates; the comparison cannot establish an independently confirmed improvement. R² on log(1+PM2.5) must not be ranked directly against original-response R²."),
            p("For a log fit, training residuals give s = mean(exp(residual)); the original-unit estimate is exp(linear predictor) × s − 1, following Duan's smearing idea [2]. The factors are "+number(S3+"model_comparison_fits.csv","smearing_factor",{"model":"M3_log"})+" and "+number(S3+"model_comparison_fits.csv","smearing_factor",{"model":"M3_log_lag_met"})+" for the two log candidates. A common factor approximates retransformation if conditional residual distributions differ. The formula bounds estimates above −1, not zero; no negative estimates is an empirical result here. Original-unit and log-response coefficients have different interpretations."),
            p("The lag is formed on the complete calendar before filtering; an unavailable prior PM2.5 day makes the lag missing. Actual earlier validation/test outcomes become available to later estimates. No current/future target is used at fitting or issuance, but this is a rolling same-day task rather than an open-loop multi-day forecast."),
            table(["AR(1) sensitivity method","M2 ρ","H1 nominal p","H2 nominal p"],ar_rows),
            p("Original iterative GLSAR bridges five two-day training gaps as one-step row transitions. A paired conditional-likelihood check holds estimation and first-observation treatment fixed, comparing row versus actual-calendar transitions ρ^d and gap-adjusted innovation variance. Calendar spacing changes estimates modestly and leaves the nominal qualitative decisions unchanged. The original table is preserved. These plug-in F references do not fully account for estimated-ρ uncertainty; Gaussian/stationary AR(1) is a working assumption. The sensitivity neither validates that assumption nor overrides Stage 2 HAC/Holm.")
        ]},
        {"title":"7. Cross-station evidence and supporting analyses", "blocks":[
            p(f"The same M1–M3 specifications are applied separately at all 12 stations using each station's eligible dates, training centers and cutoff. Every M2 wind interval lies below zero. H1 passes within-station Holm adjustment at {h1} stations and H2 at {h2}; this is not a correction over the full family of 24 tests. Stations share an airshed and weather, so agreement is consistency across dependent sites rather than independent replication. M3 improves test MAE over the training mean at {wins}/12 sites; Gucheng is the exception."),
            image("station_wind","Figure 5. M2 wind coefficients, each with an individual 7-day calendar-HAC interval. Samples and adjustment variables are station-specific."),
            h("Exploratory high-day classification"),
            p(f"An M2 logistic regression classifies daily PM2.5 at or above the full-core training 95th percentile ({cutoff} µg/m³). This quantile is not a health or regulatory threshold. The probability cutoff {logit('cutoff','.4f')} maximizes validation F1, breaking ties in favor of a higher cutoff. It is frozen before test scoring. On {ntest} test days ({logit('smog_days','.0f')} high days), TP={logit('true_positive','.0f')}, FP={logit('false_positive','.0f')}, FN={logit('false_negative','.0f')}, TN={logit('true_negative','.0f')}. AUC is {logit('auc')}, recall {logit('recall')} and precision {logit('precision')}. A 0.5 cutoff detects no high days. Good ranking does not eliminate false alarms; rare, dependent events limit precision. Nominal odds-ratio intervals assume independence and are exploratory.")
        ]},
        {"title":"8. Descriptive clustering, limitations and conclusions", "blocks":[
            p("Ward clustering uses six pollutant-specific training daily means, standardized across the 12 stations using sample standard deviation. Different pollutants can use different qualified dates. The largest merge-height gap among k=2…5 chooses two groups. Labels are ordered by mean PM2.5, not by an externally established risk or geographic class. The lower-PM2.5 group is "+group1+"; the other group is "+group2+". Stability on a new period has not been assessed."),
            image("station_profiles","Figure 6. Training pollutant profiles standardized across stations. Brackets identify the two descriptive Ward groups, not administrative or causal categories."),
            p("The principal limitations are observational confounding, omitted emissions/transport and boundary-layer information, nearest-station meteorology, possibly informative completeness filtering, changing pollution levels over time, residual dependence and heavy tails. Four historical years from one city provide limited evidence about new periods or places. Individual intervals and within-station tests do not supply simultaneous protection across the many exploratory analyses."),
            p("The core conclusion is methodological: seasonal terms can reduce SSE while residual diagnostics still reveal a deficient model, and classical and robust adjusted tests need not support identical statements. M3 improves average same-day held-out error relative to a simple baseline, yet severely understates high days and can predict negative concentrations. Smaller exploratory errors motivate richer temporal/weather structure; they do not remove the need for a fresh evaluation."),
            p("Future work should first secure a genuinely unseen period, prespecify a smaller analysis plan and define covariate availability at the intended prediction time. Sensitivity to missingness and temporal stability deserve priority. No new EWMA, ridge, neural-network or forecasting extension is implemented for this submission.")
        ]},
        {"title":"9. Reproducibility, references and assistance", "blocks":[
            p("The archive checksum is b04da438b2f331ac0ffd45aebdfec0d20d2367feb5f6948c4b1f7ce1191e33c4. The repository contains the fixed environment lock, chronological configurations, raw provenance, frozen model, dated predictions and source/output hashes. The original Stage 2 protocol is archived byte for byte; its superseded provisional deadline is retained there as historical evidence. Active submission documents use "+DEADLINE+"."),
            p("From a fresh checkout, install requirements.lock and the editable package, then run scripts/reproduce.py. Optional requirements-submission.lock and --with-submission rebuild this report and presentation. The independent aggregation and QR/HAC checks do not import the analysis package; extension checks independently reconstruct lags, smearing, logistic optimization, station fits and Ward merges. A separate dense-covariance calculation verifies the calendar-gap sensitivity. Agreement between code paths is computational verification, not new observational evidence."),
            p("Numerical claims in this document are read from generated CSV/JSON artifacts and registered with their source rows in build_manifest.json. The report text, PDF slides, editable slides and notes are generated together. Detailed commands, pass/fail results, numerical tolerances and remaining rendering limitations are recorded in reports/stage4_verification.md. Source data are never altered during document generation."),
            h("References"),
            *[p(f"[{i}] {label} {url}") for i,(label,url) in enumerate(REFS,1)],
            p("Additional method documentation: Bartlett HAC covariance, https://www.statsmodels.org/stable/generated/statsmodels.stats.sandwich_covariance.cov_hac.html ; GLSAR, https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.GLSAR.html ."),
            h("AI-assistance disclosure"), p(AI),
            p("Author and course details are intentionally neutral pending submission metadata. No institutional endorsement or course-specific approval of AI use is implied.")
        ]},
    ]

    # Each slide has a concise thesis, supporting content and a spoken explanation.
    slides = [
        dict(title="Beyond R²", section="BEIJING PM2.5 REGRESSION", subtitle=TITLE.split(": ",1)[1],
             bullets=["Multiple regression · ANOVA · residual diagnostics", "Observed same-day weather; March 2013–February 2017", "Final submission · "+DEADLINE],
             takeaway="What the model leaves unexplained matters.",
             notes="Introduce the question as a statistical adequacy investigation, not a forecasting benchmark. The title page is deliberately neutral; no author or course is invented."),
        dict(title="Does season add information beyond weather?", section="QUESTION & MOTIVATION",
             bullets=["H1: Are seasonal offsets jointly zero after weather adjustment?", "H2: Does the wind association differ by season?", "Adequacy: What structure remains in the residuals?"],
             takeaway="Association, inference and estimation error answer different questions.",
             notes="PM2.5 is the daily concentration response. Season may proxy many omitted processes; no causal interpretation is intended. Observed same-day weather defines contemporaneous estimation, not a genuine future forecast."),
        dict(title="A complete calendar and chronological holdouts", section="DATA & PREPROCESSING",
             table=(["Partition","Period","Eligible / calendar days"],[["Train","Mar 2013–Feb 2015",ntrain+" / 730"],["Validation","Mar 2015–Feb 2016",nval+" / 366"],["Test","Mar 2016–Feb 2017",ntest+" / 365"]]),
             caption="12 UCI stations · Wanliu chosen by training completeness · no target imputation",
             bullets=["Daily means: ≥18 valid hours; rainfall totals: all 24 hours.","Also require 18 jointly observed core hours; retain missing calendar positions."],
             takeaway="The station and cleaning rules were selected without future outcomes.",
             notes="UCI has 420,768 hourly station records. There are 1,461 dates and 1,441 eligible Wanliu dates. Each variable's mean uses its own qualified hours. Train-only centering and quantile thresholds prevent future information from entering preprocessing. Local time and rain-amount assumptions are documented."),
        dict(title="Three nested original-scale regressions", section="REGRESSION METHODOLOGY",
             table=(["Model","Predictors added","Parameters","Training R²"],[["M1","Temperature, wind, rain, pressure","5",fit_rows[0][2]],["M2","M1 + 3 seasonal indicators","8",fit_rows[1][2]],["M3","M2 + 3 season × wind terms","11",fit_rows[2][2]]]),
             bullets=["Training-only centering; winter is the reference season.",
                      "Original PM2.5 units preserve coefficient interpretation.",
                      "M2 wind: "+number(S2+"coefficients.csv","estimate",{"model":"M2","term":"wind_speed_c"},".1f")+" µg/m³ per m/s, adjusting for other weather and season."],
             takeaway="Higher training R² alone does not establish adequate errors.",
             notes="Explain nesting and the 3 degrees of freedom per added block. Seasonal terms in M3 compare seasons at the training mean wind; the base wind coefficient is winter's slope. Full rank and numerical conditioning are distinct from statistical precision."),
        dict(title="Classical ANOVA and robust tests differ", section="HYPOTHESIS TESTING",
             table=(["Question","F","Classical p","HAC p","Holm p"],tests),
             caption="7-calendar-day Bartlett HAC · joint χ²(3) Wald reference · two-test Holm family",
             bullets=["F = (SSE reduction / added df) / full-model residual mean square.",f"Neither primary joint test rejects at 5% (both adjusted p = {hp})."],
             takeaway="Use the prespecified adjusted inference, with its assumptions.",
             notes="Ordinary F assumes appropriate independent, homoscedastic Gaussian errors for exact calibration. HAC uses calendar-separated score pairs and the finite-sample n/(n-p) correction. Its chi-square reference is asymptotic. Fourteen/thirty-day sensitivity results are descriptive, not opportunities to choose a better p-value. Failure to reject does not prove equality."),
        dict(title="R² misses the remaining temporal structure", section="RESIDUAL DEPENDENCE",
             figure="residual_dependence", caption="Training residuals only · missing calendar positions retained",
             takeaway=f"M3 R² = {r2}, but lag-one residual correlation = {rho}.",
             notes="The lag-one estimate uses 719 pairs of observed adjacent calendar days. Daily aggregation has not made errors independent. Do not interpret the plot as causal evidence or add an iid confidence band. Remaining dynamics motivate cautious inference and later exploratory lag analysis."),
        dict(title="Shape and variance also challenge adequacy", section="RESIDUAL DIAGNOSTICS",
             figure="residual_shape", caption="M3 training residuals · no flagged observation deleted",
             takeaway="A Q–Q plot checks shape; it does not check independence.",
             notes="The upper tail departs from a normal reference, and the residual spread is not uniform. Serial, Koenker/Breusch–Pagan and influence diagnostics support this assessment but have calibration assumptions under dependence. Cook's-distance screening identifies 40 M3 points; it does not establish measurement error. All remain in the analysis."),
        dict(title="Average improvement coexists with high-day failure", section="FROZEN STAGE 2 EVALUATION",
             figure="frozen_test", caption=f"Test n={ntest} · M3 MAE {score()} vs baseline {score('training_mean')} µg/m³",
             takeaway=f"High-day signed error {score(column='mean_signed_error',group='high')} µg/m³ · 17 high days · 3 negative estimates",
             notes=f"The fixed validation-MAE rule, including 1% simplicity tolerance, selects M3. M2 is only 1.11% above the minimum. M3 test RMSE is {score(column='rmse')}; baseline RMSE is {score('training_mean','rmse')}. Overall signed error is +{score(column='mean_signed_error')}, contrasting with high-day underestimation. The training 95th-percentile cutoff is {cutoff}; no clipping or test-year refit occurred. This frozen evaluation is preserved."),
        dict(title="Exploratory gains on a separate common sample", section="STAGE 3 EXTENSIONS",
             figure="extension_mae", caption="Common sample: 721 train / 354 validation / 355 test · M3 is refitted",
             takeaway="Log + prior-day PM2.5 + extra weather lowers errors on these dates.",
             notes="Every candidate shares dates, so missing-predictor differences do not drive comparisons. Extra weather is dew point plus two wind-vector components. Log estimates use exp(linear predictor) times a training-only smearing factor minus one. That formula does not guarantee nonnegative values. Actual earlier PM2.5 is available to later same-day estimates; the lag never bridges a missing calendar day. Test-year scores are exploratory because the year was already inspected. Compare original-unit MAE, not cross-response R²."),
        dict(title="Five short gaps do not reverse the AR(1) sensitivity", section="MODEL ASSUMPTION SENSITIVITY",
             table=(["Method","M2 ρ","H1 nominal p","H2 nominal p"],ar_rows),
             caption="Training only · original GLSAR retained · paired likelihood fits isolate spacing",
             bullets=["Calendar gaps use transition ρᵈ and gap-adjusted innovation variance.","Nominal decisions agree; estimated-ρ uncertainty remains approximate."],
             takeaway="This sensitivity supports robustness to these gaps, not model validity.",
             notes="Original iterative GLSAR compresses retained rows and bridges five two-day gaps. Compare paired conditional likelihood fits with identical treatment of the first response, changing only row versus calendar spacing. Independent dense covariance calculations verify the coefficients and objective. H1 remains nominally supported, H2 not, including the within-method Holm pair. These exploratory AR-error results do not override the primary Stage 2 HAC/Holm conclusion."),
        dict(title="Wind associations across 12 dependent sites", section="CROSS-STATION COMPARISON",
             figure="station_wind", caption=f"H1 within-station Holm: {h1}/12 · H2: {h2}/12 · no full 24-test correction",
             takeaway="The 12 stations share an airshed; agreement is not independent replication.",
             notes=f"Each site uses its own eligible dates, centers and cutoff. These are M2 wind coefficients with individual HAC intervals, all below zero. Seasonal results vary. M3 improves test MAE over its station training-mean baseline at {wins}/12 sites; Gucheng is the exception. Shared weather and pollution mean the estimates are not independent experiments. All cross-station analyses are exploratory."),
        dict(title="High recall comes with many false alarms", section="OPTIONAL CLASSIFICATION",
             table=(["Test classification","Observed high","Observed below cutoff"],[["Predicted high",logit('true_positive','.0f'),logit('false_positive','.0f')],["Predicted below",logit('false_negative','.0f'),logit('true_negative','.0f')]]),
             caption=f"M2 logistic · validation-F1 cutoff {logit('cutoff','.4f')} · test AUC {logit('auc')}",
             bullets=[f"Recall {logit('recall')} · precision {logit('precision')} · only 17 test high days.","The class is a training quantile, not a regulatory or health standard."],
             takeaway="AUC describes ranking; the selected cutoff determines the false-alarm burden.",
             notes=f"Training has 37 positives out of 725 days. The concentration cutoff is {cutoff} µg/m³. The probability cutoff maximizes validation F1, with higher-threshold tie breaking; test labels play no part. The default 0.5 catches none of the test high days. Odds-ratio intervals assume independent observations and are exploratory. No clinical or public-health recommendation is made."),
        dict(title="Two groups of training pollutant profiles", section="OPTIONAL CLUSTERING",
             bullets=["Ward clustering uses six training pollutant means, standardized across stations.",
                      "Lower mean-PM2.5 group: Changping, Dingling, Huairou and Shunyi.",
                      "The other group contains eight stations; the largest merge-height gap selects k=2.",
                      "Pollutants can use different qualified dates; new-period stability is unknown."],
             takeaway="Membership describes this period; geographic or causal classes are not established.",
             notes="The largest merge-height gap for k from 2 to 5 chooses two groups. The lower mean-PM2.5 group contains "+group1+". The other group contains the remaining eight stations. Pollutant-specific completeness creates differing eligible date sets. Cluster labels are ordered by mean PM2.5, and do not identify independently validated geographic or risk classes. New-period stability is unknown."),
        dict(title="What the evidence cannot establish", section="STATISTICAL LIMITATIONS",
             bullets=["Observed weather supports same-day estimation, not advance forecasting.","Missingness, omitted drivers and temporal shifts can bias associations.","HAC cannot repair an incomplete conditional mean.","Dependent stations and rare high days limit inferential precision.","Stage 3 reuses a viewed test year; it remains exploratory."],
             takeaway="A successful rerun verifies computation, not the scientific assumptions.",
             notes="Mention nearest-station weather, emissions/transport and boundary-layer information, which are not modeled here. The period is only four years in one city. A separate numerical implementation is a check on code, not independent scientific replication. No confidence intervals based on independent test days are claimed."),
        dict(title="Conclusions and a defensible next step", section="CONCLUSIONS",
             bullets=["Seasonal terms reduce SSE; adjusted joint evidence remains insufficient at 5%.","Residual dependence and high-day failure matter beyond R².","Exploratory temporal/weather features improve errors on the observed dates.","Next: an unseen period, prespecified rules and explicit covariate availability."],
             takeaway="Report the limitations as part of the result.",
             notes="Return to the research question: statistical adequacy requires more than fit. Distinguish the chosen model's useful average error improvement from its poor behavior on high days. No new EWMA, ridge, neural-network or forecasting feature was added for submission. Any future confirmation must avoid retuning on the existing test year."),
        dict(title="Sources, reproducibility and assistance", section="REFERENCES & DISCLOSURE",
             bullets=["Chen (2017), UCI Beijing Multi-Site Air Quality · CC BY 4.0\nDataset DOI: 10.24432/C5RK5G",
                      "Duan (1983), JASA 78(383), 605–610 · smearing retransformation\nDOI: 10.1080/01621459.1983.10478017",
                      "Statsmodels official method documentation; repository contains locks,\nraw provenance, frozen scores and independent implementation checks.",
                      "AI assistance: OpenAI Codex and Anthropic Claude assisted code/drafting.\nThe submitter is responsible for interpretation and course-policy compliance."],
             takeaway="All empirical results are generated by this project's code.",
             notes=AI+" Full references, exact commands and integrity checks appear in the report and repository. No published model score is presented as our result. Title pages remain neutral pending author/course metadata.")
    ]
    return pages, slides


def setup_fonts():
    font_dir = Path(matplotlib.get_data_path()) / "fonts/ttf"
    pdfmetrics.registerFont(TTFont("DejaVu", str(font_dir/"DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DejaVu-Bold", str(font_dir/"DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold", italic="DejaVu", boldItalic="DejaVu-Bold")


def build_report(pages):
    styles = {
        "p": ParagraphStyle("Body", fontName="DejaVu", fontSize=9.5, leading=14.1, spaceAfter=9, textColor=colors.HexColor("#"+INK)),
        "h": ParagraphStyle("Heading", fontName="DejaVu-Bold", fontSize=15, leading=20, spaceAfter=12, textColor=colors.HexColor("#"+NAVY)),
        "caption": ParagraphStyle("Caption", fontName="DejaVu", fontSize=8, leading=11, spaceAfter=10, textColor=colors.HexColor("#"+MUTED)),
        "cell": ParagraphStyle("Cell", fontName="DejaVu", fontSize=8, leading=11, textColor=colors.HexColor("#"+INK)),
        "head": ParagraphStyle("Head", fontName="DejaVu-Bold", fontSize=8, leading=11, textColor=colors.white),
        "title": ParagraphStyle("Title", fontName="DejaVu-Bold", fontSize=24, leading=31, spaceAfter=19, textColor=colors.HexColor("#"+NAVY)),
    }
    story, markdown = [], ["# "+TITLE, "", "Final submission · "+DEADLINE, ""]
    story += [Spacer(1, 9*mm), Paragraph(escape(TITLE), styles["title"]),
              Paragraph("Statistical investigation · Final submission · "+DEADLINE, styles["p"]), Spacer(1, 5*mm)]
    for i, page in enumerate(pages):
        if i:
            story.append(PageBreak())
        story.append(Paragraph(escape(page["title"]), styles["h"]))
        markdown += ["## "+page["title"], ""]
        for block in page["blocks"]:
            kind = block["kind"]
            if kind in ("p", "h"):
                story.append(Paragraph(escape(block["text"]), styles[kind]))
                markdown += [("### " if kind == "h" else "")+block["text"], ""]
            elif kind == "image":
                filename = "figures/"+block["name"]+".png"
                with PILImage.open(OUT/filename) as image:
                    width, height = image.size
                story.append(Image(str(OUT/filename), width=174*mm, height=174*mm*height/width))
                story.append(Paragraph(escape(block["caption"]), styles["caption"]))
                markdown += [f"![{block['caption']}]({filename})", ""]
            else:
                rows = [block["headers"], *block["rows"]]
                cells = [[Paragraph(escape(str(cell)), styles["head" if r==0 else "cell"]) for cell in row]
                         for r,row in enumerate(rows)]
                # Wider first column for descriptive labels; equal numerical columns.
                n = len(rows[0])
                ratios = ([.25,.42,.33] if n==3 and "Partition" in rows[0] else
                          [.29]+[.71/(n-1)]*(n-1))
                table = Table(cells, colWidths=[174*mm*v for v in ratios], repeatRows=1, hAlign="LEFT")
                table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#"+NAVY)),
                    ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.HexColor("#"+PALE),colors.white]),
                    ("VALIGN",(0,0),(-1,-1),"TOP"),("TOPPADDING",(0,0),(-1,-1),7),
                    ("BOTTOMPADDING",(0,0),(-1,-1),7),("LEFTPADDING",(0,0),(-1,-1),7),
                    ("LINEBELOW",(0,-1),(-1,-1),.5,colors.HexColor("#CEDAE2"))]))
                story += [table, Spacer(1, 11)]
                markdown += ["| "+" | ".join(block["headers"])+" |", "| "+" | ".join(["---"]*n)+" |",
                             *["| "+" | ".join(map(str,row))+" |" for row in block["rows"]], ""]

    def footer(c, doc):
        c.saveState()
        c.setStrokeColor(colors.HexColor("#CEDAE2"))
        c.line(18*mm,17*mm,192*mm,17*mm)
        c.setFont("DejaVu",7.5)
        c.setFillColor(colors.HexColor("#"+MUTED))
        c.drawString(18*mm,12*mm,"Beyond R² · Beijing PM2.5 · "+DEADLINE)
        c.drawRightString(192*mm,12*mm,str(doc.page))
        c.restoreState()

    doc = SimpleDocTemplate(str(OUT/"report.pdf"), pagesize=A4, rightMargin=18*mm,
                            leftMargin=18*mm, topMargin=18*mm, bottomMargin=23*mm,
                            title=TITLE, author="", subject="Regression, ANOVA and model adequacy")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    (OUT/"report.md").write_text("\n".join(markdown), encoding="utf-8")


def slide_elements(slides):
    """Coordinates are points on a 960 × 540 canvas, shared by PPTX and PDF."""
    all_elements = []
    for i,s in enumerate(slides):
        elements = []

        def rect(x,y,w,h,color):
            elements.append(dict(kind="rect",x=x,y=y,w=w,h=h,color=color))

        def text(value,x,y,w,h,size=23,color=INK,bold=False):
            elements.append(dict(kind="text",text=value,x=x,y=y,w=w,h=h,size=size,color=color,bold=bold))

        rect(0,0,960,540,"FFFFFF")
        rect(0,0,960,9,TEAL)
        text(s["section"],40,24,850,22,12,TEAL,True)
        text(s["title"],40,58,880,72 if i==0 else 53,38 if i==0 else 29,NAVY,True)
        if i==0:
            text(s["subtitle"],40,138,850,104,29,NAVY,True)
            for j,b in enumerate(s["bullets"]):
                text(b,40,286+j*43,880,39,21,MUTED)
        elif "figure" in s:
            image_path = FIG/(s["figure"]+".png")
            with PILImage.open(image_path) as im:
                iw, ih = im.size
            w,h = min(860,300*iw/ih),min(300,860*ih/iw)
            elements.append(dict(kind="image",path=str(image_path.relative_to(ROOT)),x=(960-w)/2,y=120,w=w,h=h))
            text(s["caption"],40,431,880,34,15,MUTED)
        elif "table" in s:
            headers, rows = s["table"]
            n = len(headers)
            widths = ([250,300,330] if n==3 else [280,120,160,160,160] if n==5 else
                      [90,470,150,170] if s["section"]=="REGRESSION METHODOLOGY" else
                      [330,130,210,210])
            y, row_height = 126, 48
            for r,row in enumerate([headers,*rows]):
                x=40
                for j,cell in enumerate(row):
                    rect(x,y+r*row_height,widths[j],row_height,NAVY if r==0 else (PALE if r%2 else "FFFFFF"))
                    text(str(cell),x+9,y+r*row_height+10,widths[j]-18,38,17 if r==0 else 20,
                         "FFFFFF" if r==0 else INK,r==0)
                    x+=widths[j]
            bottom = y+(len(rows)+1)*row_height
            if s.get("caption"):
                text(s["caption"],40,bottom+14,880,33,15,MUTED)
                bottom += 48
            for j,b in enumerate(s.get("bullets",[])):
                text("• "+b,40,bottom+14+j*43,880,39,21)
        else:
            many = len(s["bullets"])>4
            for j,b in enumerate(s["bullets"]):
                size = 21 if s["section"]=="REFERENCES & DISCLOSURE" else 22 if many else 23
                text("• "+b,40,136+j*(59 if many else 79),880,64 if not many else 53,size)
        rect(32,475,896,43,PALE)
        text(s["takeaway"],44,485,872,29,17,TEAL,True)
        text("Beyond R² · Beijing PM2.5",40,524,700,14,9,MUTED)
        text(f"{i+1:02d} / {len(slides):02d}",861,524,65,14,9,MUTED)
        all_elements.append(elements)
    return all_elements


def wrapped_lines(text, font, size, width):
    lines = []
    for original in text.split("\n"):
        line = ""
        for word in original.split():
            candidate = (line+" "+word).strip()
            if line and pdfmetrics.stringWidth(candidate,font,size)>width:
                lines.append(line)
                line = word
            else:
                line = candidate
        lines.append(line)
    return lines


def build_slides(slides):
    prs = Presentation()
    prs.slide_width, prs.slide_height = Pt(960), Pt(540)
    prs.core_properties.title = TITLE
    prs.core_properties.author = ""
    prs.core_properties.subject = "Statistical investigation; final submission "+DEADLINE
    pdf = canvas.Canvas(str(OUT/"slides.pdf"), pagesize=(960,540), invariant=1)
    pdf.setTitle(TITLE)
    pdf.setAuthor("")
    elements = slide_elements(slides)
    notes = ["# Presentation speaker notes", "", TITLE, "", "Final submission · "+DEADLINE,"",
             "Slides use generated analysis tables. Stage 2 is the prespecified core; Stage 3 and the AR(1) sensitivity are exploratory.",""]
    for i,(s,items) in enumerate(zip(slides,elements)):
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        slide.notes_slide.notes_text_frame.text = s["notes"]
        notes += [f"## {i+1}. {s['title']}","",s["notes"],""]
        for item in items:
            x,y,w,h = (item[k] for k in ("x","y","w","h"))
            kind = item["kind"]
            if kind=="rect":
                shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,Pt(x),Pt(y),Pt(w),Pt(h))
                shape.fill.solid()
                shape.fill.fore_color.rgb = RGBColor.from_string(item["color"])
                shape.line.fill.background()
                pdf.setFillColor(colors.HexColor("#"+item["color"]))
                pdf.rect(x,540-y-h,w,h,stroke=0,fill=1)
            elif kind=="image":
                slide.shapes.add_picture(str(ROOT/item["path"]),Pt(x),Pt(y),width=Pt(w),height=Pt(h))
                pdf.drawImage(str(ROOT/item["path"]),x,540-y-h,w,h)
            else:
                shape = slide.shapes.add_textbox(Pt(x),Pt(y),Pt(w),Pt(h))
                tf = shape.text_frame
                tf.word_wrap = True
                tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
                font = "DejaVu-Bold" if item["bold"] else "DejaVu"
                size = item["size"]
                lines = wrapped_lines(item["text"],font,size,w)
                if len(lines)*size*1.15 > h+3:
                    raise ValueError(f"Slide {i+1} text exceeds its box: {item['text']}")
                for j,line in enumerate(lines):
                    para = tf.paragraphs[0] if j==0 else tf.add_paragraph()
                    para.text=line
                    para.font.name="DejaVu Sans"
                    para.font.size=Pt(size)
                    para.font.bold=item["bold"]
                    para.font.color.rgb=RGBColor.from_string(item["color"])
                    para.line_spacing=1.15
                    para.space_after=Pt(0)
                pdf.setFillColor(colors.HexColor("#"+item["color"]))
                pdf.setFont(font,size)
                for j,line in enumerate(lines):
                    pdf.drawString(x,540-y-size-j*size*1.15,line)
        pdf.showPage()
    pdf.save()
    prs.save(str(OUT/"slides.pptx"))
    (OUT/"speaker_notes.md").write_text("\n".join(notes),encoding="utf-8")
    (OUT/"slide_content.json").write_text(json.dumps({"title":TITLE,"deadline":DEADLINE,
             "slides":slides,"elements":elements},indent=2,ensure_ascii=False)+"\n",encoding="utf-8")


def main():
    FIG.mkdir(parents=True,exist_ok=True)
    setup_fonts()
    figures()
    pages,slides = content()
    build_report(pages)
    build_slides(slides)
    for name in ("scripts/build_submission.py","scripts/check_submission.py","requirements.lock", "requirements-submission.lock"):
        source(name)
    outputs = ["submission/report.md","submission/report.pdf","submission/slides.pdf",
               "submission/slides.pptx","submission/speaker_notes.md","submission/slide_content.json"]
    outputs += [str(p.relative_to(ROOT)) for p in sorted(FIG.glob("*.png"))]
    manifest = {"title":TITLE,"deadline":DEADLINE,"neutral_title_pages":True,
                "stage2_frozen_model":frozen_reference(), "stage3_is_exploratory":True,
                "input_sha256":INPUTS,"output_sha256":{p:sha(ROOT/p) for p in outputs},
                "numerical_claims":list(CLAIMS.values()),"slide_count":len(slides),
                "environment":{n:importlib.metadata.version(n) for n in
                               ("numpy","pandas","matplotlib","scipy","reportlab","python-pptx","PyMuPDF")},
                "rendering_note":"PDF slides are directly rendered from the same content and geometry as PPTX. Native PowerPoint rendering requires an Office-compatible viewer and is not asserted by this build."}
    (OUT/"build_manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(f"Built report, {len(slides)} slides, notes and {len(CLAIMS)} source-linked numerical claims in submission/.")


def frozen_reference():
    return {"source":"results/stage2/frozen_model.json", "sha256":sha(ROOT/"results/stage2/frozen_model.json"),
            "retuned":False,"test_refitted":False,"negative_estimates_clipped":False}


if __name__=="__main__":
    main()
