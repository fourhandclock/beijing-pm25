# Beyond R²: Beijing PM2.5

**Seasonal Effects, Residual Dependence, and Model Adequacy in Beijing PM2.5 Regression**

Final submission deadline: **24 November 2026**.

A reproducible statistical investigation of daily PM2.5 at Beijing monitoring stations. The core analysis uses multiple regression, nested-model ANOVA, calendar-aware HAC joint tests and residual diagnostics. **Stage 2 is the prespecified confirmatory analysis; Stage 3 is exploratory**, developed after the original test year had been evaluated. All estimates use observed same-day weather and do not measure advance-forecasting skill.

## Read the submission

| Material | Purpose |
| --- | --- |
| [Academic report (PDF)](submission/report.pdf) · [source text](submission/report.md) | Research question, methods, evidence and limitations |
| [Presentation (PDF)](submission/slides.pdf) · [PowerPoint](submission/slides.pptx) · [speaker notes](submission/speaker_notes.md) | Self-contained presentation of the statistical argument |
| [Final verification report](reports/stage4_verification.md) | Commands, fresh-clone results, discrepancies and readiness |
| [Statistical audit](reports/stage4/statistical_audit.md) | Independent checks, interpretation corrections and AR(1) gap sensitivity |
| [Stage 1 data audit](reports/stage1_summary.md) | Selection, missingness, aggregation and preprocessing |
| [Stage 2 analysis](reports/stage2_analysis.md) · [protocol](reports/stage2_protocol.md) | Frozen original-scale regression and tests |
| [Stage 3 extensions](reports/stage3_extensions.md) | Supplementary log/lag/weather models, stations, classification and clustering |

Title pages are neutral. AI assistance is disclosed in the report, slides and below. Course-specific author details or prescribed wording can be added before submission.

## Main findings

Wanliu was selected using training-period completeness. Of 1,461 calendar dates, 1,441 meet the fixed requirements: **725 training, 359 validation and 357 test days**. The fixed validation rule selects M3. Its frozen test **MAE is 46.785 µg/m³** and **RMSE is 60.935 µg/m³**, compared with 55.297 and 73.006 for the training-mean baseline.

Neither primary HAC joint test rejects at 5% after the prespecified two-test Holm adjustment (both adjusted p = 0.0618). M3's training R² is 0.221, but residual lag-one correlation is 0.512. On 17 high-pollution test days, mean estimate minus observation is −160.945 µg/m³. Three negative estimates remain in the scores. These are material model limitations.

Stage 3 compares five candidates on a **different common sample, 721/354/355 days**. Its M3 is a refit on that sample. The combined log/lag/weather model has validation MAE 32.7 and descriptive test MAE 29.0, versus about 50.4 and 46.7 for the common-sample M3. Those errors cannot replace the frozen Stage 2 evaluation. Log retransformation produced no negative estimates in this run; it does not mathematically guarantee nonnegativity. The prior day's actual PM2.5 is used only after it becomes available.

All 12 stations have negative M2 wind associations with individual HAC intervals below zero. Stations are dependent, and their two-test Holm adjustments are not a correction across all 24 joint tests. Validation selects a logistic probability cutoff of 0.1323: it catches 15 of 17 test high days with 44 false alarms. This class is a training quantile, not a health standard. Two training-profile clusters describe station differences without establishing a geographic or causal classification.

## Reproduce from a fresh clone

Run from the repository root. Python **3.13.16** was used for verification. `requirements.lock` pins the numerical and test environment; Python 3.11+ is supported by the package, but other interpreters/OS builds have not all been verified.

```bash
git clone https://github.com/fourhandclock/beijing-pm25.git
cd beijing-pm25
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python scripts/reproduce.py
```

The runner downloads the original archive, reruns Stages 1–3 in order, runs pytest with warnings treated as errors, checks independent aggregation/model/extension implementations, audits AR(1) gaps, checks frozen Stage 2 preservation and runs `verify`. It stops on failure and records exact commands, durations and logs under `reports/stage4/reproduction/`. Each subprocess has a timeout; Ctrl-C cancels the active process.

To rebuild and check the report and slides as part of that run:

```bash
.venv/bin/python -m pip install -r requirements-submission.lock
.venv/bin/python scripts/reproduce.py --with-submission
```

The optional document packages do not replace or relax the scientific lock. To rebuild only the documents after a successful analysis:

```bash
.venv/bin/python scripts/build_submission.py
.venv/bin/python scripts/check_submission.py
```

`build_submission.py` reads generated tables, not hand-entered results. It produces Markdown/PDF report, PDF/PowerPoint slides, notes, readable figures and a source/output checksum manifest. The PDF and PowerPoint use the same slide content. Document checks compare numerical claims with their source rows and inspect page text, fonts and layout bounds. The final verification report identifies the scope of visual inspection.

### Individual analysis and verification commands

```bash
.venv/bin/python -m beijing_pm25 download
.venv/bin/python -W error -m beijing_pm25 stage1
.venv/bin/python -W error -m beijing_pm25 stage2
.venv/bin/python -W error -m beijing_pm25 stage3
.venv/bin/python -W error -m pytest -q
python3 scripts/verify_aggregation.py
.venv/bin/python -W error scripts/verify_models.py
.venv/bin/python -W error scripts/verify_extensions.py
.venv/bin/python -W error scripts/audit_ar1_calendar.py
.venv/bin/python scripts/check_frozen_stage2.py
.venv/bin/python scripts/check_stage3_preservation.py
.venv/bin/python -m beijing_pm25 verify
```

`verify` checks stages with run records; `verify --stage 1`, `--stage 2` and `--stage 3` select a stage and its prerequisites. Tracked run records are evidence of previous execution. Ignored processed CSVs must be regenerated in a fresh clone. Changes to source, declared inputs or dependencies require rerunning **Stage 1, then Stage 2, then Stage 3** to refresh hashes. This regeneration preserves the original Stage 2 method and frozen numerical evaluation; it does not make an already viewed test year unseen.

### Acquisition and provenance

Source: Chen, S. (2017). [Beijing Multi-Site Air Quality](https://doi.org/10.24432/C5RK5G), UCI Machine Learning Repository, **CC BY 4.0**. [UCI documentation](https://archive.ics.uci.edu/dataset/501/beijing+multi+site+air+quality+data) describes 420,768 hourly station observations at 12 sites, March 2013–February 2017, with meteorology matched from nearby weather stations.

The raw archive is ignored by Git; [provenance.json](data/raw/provenance.json) is committed. A new download must match its SHA-256:

```text
b04da438b2f331ac0ffd45aebdfec0d20d2367feb5f6948c4b1f7ce1191e33c4
```

The download command preserves that manifest and archive bytes, verifies/reuses existing files, and has network/time/size limits. It does not fabricate data after a failed acquisition. Installation and downloading need network access; subsequent runs work offline. A manually obtained original UCI wrapper or inner station ZIP can be imported with:

```bash
.venv/bin/python -m beijing_pm25 download --import-archive /path/to/original.zip
```

A local import records its unverified download origin. Standard-library-only acquisition is also available using `PYTHONPATH=src python3 -m beijing_pm25 download`.

## Data and statistical decisions

[Stage 1 configuration](config/stage1.json) fixes these rules:

- Preserve separate hourly/daily calendars and station labels; reject malformed values and duplicate timestamps. Do not combine stations or impute missing outcomes.
- Daily means require at least **18 valid hours** for each core variable. Rainfall totals require **24 valid hourly amounts**. An analysis day also needs 18 hours with all five core fields jointly observed.
- Mask/count nonfinite or physically invalid values. Retain valid zeros, negative temperatures and high positive pollution measurements; no outcome-based trimming.
- Use local civil dates, assumed Asia/Shanghai because the source does not explicitly give a timezone. Interpret rain values as hourly interval amounts; this is an instrument assumption.
- Training: 2013-03-01 to 2015-03-01 exclusive. Validation: the next year to 2016-03-01 exclusive. Test: the next year to 2017-03-01 exclusive.
- Rank stations by eligible training-day count, then valid training PM2.5 hours, then name. Concentration and future coverage do not select Wanliu.

[Stage 2 configuration](config/stage2.json) and the [prefit protocol](reports/stage2_protocol.md) fix the original response scale, train-only centering, winter reference, three nested models, 7/14/30-calendar-day HAC, two-test primary Holm correction, 1% validation-MAE simplicity rule and training-only 95th-percentile high-day cutoff. Negative estimates are retained. The original dated protocol is preserved in [the archive](reports/archive/stage2_protocol_original_20261119.md), including its superseded provisional deadline.

[Stage 3 configuration](config/stage3.json) keeps new analyses separate. Dew point and wind vectors follow the 18-hour rule. `southerly`/`westerly` are positive for air from the south/west. The lag is the previous **calendar day's** eligible PM2.5, missing after an unavailable day. A one-factor training-only Duan smearing estimate returns log fits to concentration units. R² values on different response scales are not directly comparable.

## Repository guide

| Directory/file | Contents |
| --- | --- |
| `data/raw/` | Unchanged original archive and committed provenance |
| `data/processed/` | Ignored complete-calendar and eligible-day CSVs, rebuilt by Stage 1 |
| `results/tables/`, `results/figures/`, `results/stage1_run.json` | Selection, missingness, distributions, calendar ACF and run record |
| `results/stage2/` | Frozen model, all fit parameters, coefficients, ANOVA/HAC matrices, diagnostics, dated predictions, scores and figures |
| `results/stage3/` | Common-sample models, original GLSAR, all stations, logistic probabilities/threshold and Ward profiles |
| `results/stage4/` | Separate training-only AR(1) calendar-gap sensitivity; original GLSAR table is retained |
| `reports/stage4/` | Baseline snapshot, statistical audit and machine-readable verification evidence |
| `submission/` | Final report, presentation, notes, scientific figures and build manifest |
| `src/beijing_pm25/` | Acquisition, aggregation, statistical models, reporting and CLI |
| `scripts/` | Reproduction/document builders, preservation guards and independent verification |
| `tests/` | Synthetic correctness fixtures, never represented as observed data |

Daily variables use µg/m³ for PM2.5, °C for temperature/dew point, hPa for pressure, m/s for wind and mm/day for rainfall under the stated assumption. Empty numeric cells are missing, not zeros. Keep complete-calendar data for lag/ACF work; consecutive filtered rows can be several days apart.

## Interpretation and disclosure

This is observational association. Missingness, omitted emissions and transport, spatially matched weather, temporal shifts and residual dependence limit inference. HAC addresses some covariance misspecification under its assumptions; it cannot repair a deficient conditional mean. The 12 stations share one city's environment and are not independent replications. Small high-day samples limit precision. Stage 3's reused test year provides descriptive comparisons; new confirmation requires an unseen period and prespecified rules. No new EWMA, ridge, neural-network or forecasting extension is included.

The project was developed with AI coding assistants (OpenAI Codex and Anthropic Claude). Codex assisted the Stage 4 verification, document code and drafting. Numerical claims are tied to generated tables and separate implementation checks; these checks do not constitute independent scientific replication. The submitter remains responsible for interpretation, authorship and compliance with the course's AI-assistance policy. No course-specific policy wording or institutional endorsement is asserted.
