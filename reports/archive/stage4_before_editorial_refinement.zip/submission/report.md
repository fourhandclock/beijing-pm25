# Beyond R²: Seasonal Effects, Residual Dependence, and Model Adequacy in Beijing PM2.5 Regression

Final submission · 24 November 2026

## Abstract and research question

Daily pollution regression can explain an average pattern while leaving errors that undermine conventional inference and practical use. This investigation asks whether seasonal indicators and season-specific wind associations add information beyond observed weather, and whether residual diagnostics support the adequacy of the resulting multiple regressions.

The UCI Beijing Multi-Site Air Quality dataset supplies hourly records at 12 stations. Wanliu is selected using training-period completeness. Three nested original-scale models are fitted on 725 training days; 359 validation days select a specification by a fixed rule, followed by a frozen 357-day test evaluation. Classical nested-model ANOVA is accompanied by calendar-aware HAC joint tests and the prespecified Holm correction.

Validation selects M3, with training R² 0.221 and test MAE 46.785 µg/m³, versus 55.297 for the training-mean baseline. Both primary joint tests have Holm-adjusted p = 0.0618, so neither rejects at 5%. Residual lag-one correlation is 0.512; severe high-day underestimation and negative estimates expose limitations that R² alone does not describe.

Later log/lag/weather alternatives, an AR(1) sensitivity analysis, cross-station comparisons, classification and clustering are exploratory. They were developed after the original test year had been inspected. Their numerical improvements motivate future study; they are not fresh confirmatory evidence. Every model uses actual same-day weather and therefore estimates contemporaneous concentrations rather than producing genuine advance forecasts.

### Scope of the evidence

| Analysis | Role | Evaluation status |
| --- | --- | --- |
| Stage 2 | Prespecified core regression | Original frozen test retained |
| Stage 3 | Exploratory extensions | Previously viewed test year |
| Stage 4 | Verification and sensitivity | No new confirmatory period |

Keywords: multiple regression; nested-model ANOVA; HAC covariance; residual dependence; model adequacy; PM2.5.

## 1. Data, preprocessing and evaluation design

Chen's UCI dataset contains 420,768 hourly station records from March 2013 through February 2017 at 12 Beijing sites. Weather observations are matched from nearby weather stations. The original archive is preserved unchanged and identified by its committed SHA-256 checksum. Data are attributed to Chen (2017), UCI, under CC BY 4.0 [1,4].

Station selection is based only on eligible training-day count, then valid training PM2.5-hour count, then alphabetical name. Wanliu ranks first. The analysis preserves a complete 1,461-day calendar, keeping unavailable dates explicit. It rejects duplicate/malformed timestamps and mixed station labels; invalid physical measurements are masked and counted. Valid zeros, negative temperatures and high positive pollution readings are retained.

Daily PM2.5, temperature, pressure and wind-speed means each require 18 valid hours. Rain totals require all 24 hourly amounts, and an analysis day needs 18 hours with all five core fields jointly observed. Means use each variable's own valid hours. Missing outcomes are neither imputed nor treated as zero. Completeness exclusions can be selective, so retaining many dates is not proof of representativeness.

| Partition | Dates (end exclusive) | Retained / calendar days |
| --- | --- | --- |
| Training | 2013-03-01 to 2015-03-01 | 725 / 730 |
| Validation | 2015-03-01 to 2016-03-01 | 359 / 366 |
| Test | 2016-03-01 to 2017-03-01 | 357 / 365 |

The 1,441 eligible days exclude 20 calendar dates. Timestamps are treated as local civil dates, assumed Asia/Shanghai because the source does not explicitly specify a timezone. Summing rainfall assumes the source entries are hourly interval amounts. These are documented measurement assumptions, not verified instrument specifications.

All centering constants, training means and high-day thresholds use training data only. Validation MAE is used for model selection; final test responses do not enter that rule. The high-day cutoff is the eligible training daily 95th percentile, 234.655 µg/m³, distinct from any hourly threshold or regulatory category. Chronological splitting reduces direct future-to-past leakage but does not remove dependence or distribution shifts.

## 2. Multiple regression and planned hypotheses

Let Y be daily PM2.5 in µg/m³, and T, W, R and P be centered daily temperature, wind speed, rainfall and pressure. Winter is the reference season, with three indicators S for spring, summer and autumn. Centering uses training means and changes interpretation, not the fitted model family.

M1: E(Y | X) = β₀ + βT T + βW W + βR R + βP P. M2 adds Σ γs Ss. M3 additionally adds Σ δs (W × Ss). The models have 5, 8 and 11 parameters. Each training design is full rank; numerical conditioning is checked separately from statistical uncertainty.

| Model | Parameters | R² | Adjusted R² | SSE |
| --- | --- | --- | --- | --- |
| M1 | 5 | 0.198 | 0.194 | 2731346.5 |
| M2 | 8 | 0.213 | 0.206 | 2679559.7 |
| M3 | 11 | 0.221 | 0.211 | 2652408.5 |

H1 tests whether the three seasonal coefficients in M2 are jointly zero after weather adjustment (M1 versus M2). H2 tests whether the three wind-by-season coefficients in M3 are jointly zero (M2 versus M3). Under M3, seasonal offsets apply at the training mean wind speed; its base wind coefficient is the winter slope. Joint tests are the planned inferential questions, rather than a search among individual coefficient p-values.

Nested-model ANOVA uses F = [(SSErestricted − SSEfull) / q] / [SSEfull / (n − pfull)], with q = 3 added parameters in each comparison. The exact F reference requires an appropriate linear mean and independent, homoscedastic Gaussian errors. The ordinary calculation is informative about fit reduction, but its nominal significance is vulnerable when diagnostics reveal dependence or unequal variance [3].

| Question | F | Classical p | 7-day HAC p | Primary Holm p |
| --- | --- | --- | --- | --- |
| H1: add season | 4.619 | 0.0033 | 0.0359 | 0.0618 |
| H2: wind × season | 2.436 | 0.0636 | 0.0309 | 0.0618 |

For primary inference, Bartlett-weight calendar HAC estimates covariance using observed score products at actual date separations, with unavailable daily positions contributing zero scores. The n/(n−p) correction is applied. A 7-day bandwidth is primary; 14/30-day values are descriptive sensitivities. Wald joint statistics use an asymptotic χ²(3) reference. Holm correction covers the two prespecified primary hypotheses. Neither rejects at α = 0.05; this is insufficient evidence against those nulls, not proof of no seasonal structure. HAC cannot correct an inadequate mean, informative missingness or omitted confounding.

## 3. Conditional interpretation of coefficients

| M2 predictor (one unit) | Estimated difference (µg/m³) | Individual 95% HAC interval |
| --- | --- | --- |
| Temperature (°C) | -2.483 | [-3.985, -0.982] |
| Wind (m/s) | -49.030 | [-57.608, -40.453] |
| Rain (mm/day) | -0.203 | [-1.043, 0.637] |
| Pressure (hPa) | -2.246 | [-3.467, -1.026] |

A weather coefficient describes the fitted concentration difference associated with one additional unit, conditional on the other listed predictors and season. For example, M2's wind coefficient is -49.030 µg/m³ per m/s, with interval [-57.608, -40.453]. It is an adjusted observational association. It does not estimate the effect of artificially increasing wind or identify the mechanism producing pollution.

The four seasonal wind slopes in M3 combine the base coefficient and its interaction. Their intervals use the full contrast covariance, including covariance between those terms. The intervals are individual rather than simultaneous; a negative point estimate for summer does not establish a nonzero summer association when its interval includes zero.

![Figure 1. Training M3 wind associations with individual 7-calendar-day HAC intervals. Source: m3_seasonal_wind_slopes.csv.](figures/seasonal_wind.png)

Temperature, pressure and season are related. Their conditional coefficients should not be equated with marginal correlations or simple seasonal mean differences. A nonsignificant contrast does not demonstrate equality, and a narrow individual interval does not rescue misspecified errors. The primary joint-test conclusion remains governed by the prespecified two-test adjustment.

## 4. Residual diagnostics: adequacy beyond R²

Training R² rises only from 0.198 to 0.221. More importantly, M3 residuals retain a lag-one paired-calendar correlation of 0.512. Calendar-aware plots retain missing daily positions; consecutive retained rows are not automatically treated as consecutive days. The remaining structure suggests that the weather-and-season mean is incomplete.

![Figure 2. Calendar-lag training residual correlations for M3. Pair counts vary by lag; no iid confidence band is asserted.](figures/residual_dependence.png)

![Figure 3. Training residual-versus-fitted and normal Q–Q plots. Upper-tail departures and changing spread warrant caution about Gaussian/iid calibration.](figures/residual_shape.png)

The serial auxiliary regression uses the preceding seven calendar-day residuals, retaining only rows with all auxiliary lags. Its diagnostic p-value is approximate. Breusch–Pagan/Koenker, Jarque–Bera and influence checks also require assumptions; their small nominal p-values are supporting evidence, not an independence certificate. Forty M3 observations exceed the Cook's-distance 4/n screening guide; none is deleted. A Q–Q plot concerns distributional shape, not temporal independence.

## 5. Validation choice and the frozen test year

| Candidate | Validation MAE | Validation RMSE |
| --- | --- | --- |
| M1 | 52.025 | 65.519 |
| M2 | 50.660 | 64.579 |
| M3 | 50.104 | 64.171 |

The unchanged rule minimizes validation MAE, preferring fewer parameters among models within 1% of the minimum. It chooses M3. M2 is only 1.11% worse than the minimum, just outside that tolerance: this small difference should not be portrayed as decisive superiority. Inference p-values and test errors do not select the model. Coefficients, centers, baseline and high-day cutoff are persisted before final scoring, with no validation/test refit and no clipping.

| Test evaluation | MAE | RMSE | Mean estimate − observation |
| --- | --- | --- | --- |
| M3 | 46.785 | 60.935 | 15.283 |
| Training mean | 55.297 | 73.006 | 12.897 |
| M3: high days only | 160.945 | 173.583 | -160.945 |

Errors are in µg/m³. The overall comparison uses 357 eligible dates. The high-day M3 row uses only 17 days at or above the training cutoff. Overall bias is positive, but high-day bias is negative: aggregation conceals a different error direction during severe episodes. The selected model has 3 negative test estimates, retained as evidence of a physical limitation of unrestricted linear regression.

![Figure 4. Frozen Stage 2 test estimates using observed same-day weather. Missing dates break lines; the graph is descriptive after selection.](figures/frozen_test.png)

These are held-out contemporaneous estimates, not advance forecasts. Dependence makes naive independent-day confidence intervals for error differences inappropriate; none is claimed. Reproducing the frozen evaluation verifies the computation but cannot restore the original test year's unseen status.

## 6. Exploratory improvements and AR(1) sensitivity

Stage 3 adds a log1p response, prior-calendar-day PM2.5, and extra weather (dew point and two wind-vector components). All five candidates use the same 721 training, 354 validation and 355 test dates. Their M3 is a refit on this common sample, not the frozen Stage 2 evaluation. The slightly changed sample also changes its training high-day cutoff.

| Common-sample model | Validation MAE | Test MAE* | Test RMSE* |
| --- | --- | --- | --- |
| M3 refit | 50.4 | 46.7 | 60.9 |
| Log M3 | 50.0 | 45.1 | 58.3 |
| M3 + prior PM2.5 | 37.7 | 35.5 | 47.8 |
| M3 + extra weather | 46.9 | 40.7 | 55.4 |
| Log + lag + weather | 32.7 | 29.0 | 40.8 |

*The test year was already viewed before Stage 3, so its scores are descriptive. The combined candidate is selected by validation MAE within this exploratory set. Its errors are smaller on these dates; the comparison cannot establish an independently confirmed improvement. R² on log(1+PM2.5) must not be ranked directly against original-response R².

For a log fit, training residuals give s = mean(exp(residual)); the original-unit estimate is exp(linear predictor) × s − 1, following Duan's smearing idea [2]. The factors are 1.239 and 1.117 for the two log candidates. A common factor approximates retransformation if conditional residual distributions differ. The formula bounds estimates above −1, not zero; no negative estimates is an empirical result here. Original-unit and log-response coefficients have different interpretations.

The lag is formed on the complete calendar before filtering; an unavailable prior PM2.5 day makes the lag missing. Actual earlier validation/test outcomes become available to later estimates. No current/future target is used at fitting or issuance, but this is a rolling same-day task rather than an open-loop multi-day forecast.

| AR(1) sensitivity method | M2 ρ | H1 nominal p | H2 nominal p |
| --- | --- | --- | --- |
| Original GLSAR rows | 0.572 | 0.0033 | 0.4616 |
| Likelihood rows | 0.571 | 0.0033 | 0.4610 |
| Likelihood calendar | 0.583 | 0.0026 | 0.4475 |

Original iterative GLSAR bridges five two-day training gaps as one-step row transitions. A paired conditional-likelihood check holds estimation and first-observation treatment fixed, comparing row versus actual-calendar transitions ρ^d and gap-adjusted innovation variance. Calendar spacing changes estimates modestly and leaves the nominal qualitative decisions unchanged. The original table is preserved. These plug-in F references do not fully account for estimated-ρ uncertainty; Gaussian/stationary AR(1) is a working assumption. The sensitivity neither validates that assumption nor overrides Stage 2 HAC/Holm.

## 7. Cross-station evidence and supporting analyses

The same M1–M3 specifications are applied separately at all 12 stations using each station's eligible dates, training centers and cutoff. Every M2 wind interval lies below zero. H1 passes within-station Holm adjustment at 6 stations and H2 at 2; this is not a correction over the full family of 24 tests. Stations share an airshed and weather, so agreement is consistency across dependent sites rather than independent replication. M3 improves test MAE over the training mean at 11/12 sites; Gucheng is the exception.

![Figure 5. M2 wind coefficients, each with an individual 7-day calendar-HAC interval. Samples and adjustment variables are station-specific.](figures/station_wind.png)

### Exploratory high-day classification

An M2 logistic regression classifies daily PM2.5 at or above the full-core training 95th percentile (234.655 µg/m³). This quantile is not a health or regulatory threshold. The probability cutoff 0.1323 maximizes validation F1, breaking ties in favor of a higher cutoff. It is frozen before test scoring. On 357 test days (17 high days), TP=15, FP=44, FN=2, TN=296. AUC is 0.927, recall 0.882 and precision 0.254. A 0.5 cutoff detects no high days. Good ranking does not eliminate false alarms; rare, dependent events limit precision. Nominal odds-ratio intervals assume independence and are exploratory.

## 8. Descriptive clustering, limitations and conclusions

Ward clustering uses six pollutant-specific training daily means, standardized across the 12 stations using sample standard deviation. Different pollutants can use different qualified dates. The largest merge-height gap among k=2…5 chooses two groups. Labels are ordered by mean PM2.5, not by an externally established risk or geographic class. The lower-PM2.5 group is Changping, Dingling, Huairou, Shunyi; the other group is Aotizhongxin, Dongsi, Guanyuan, Gucheng, Nongzhanguan, Tiantan, Wanliu, Wanshouxigong. Stability on a new period has not been assessed.

![Figure 6. Training pollutant profiles standardized across stations. Brackets identify the two descriptive Ward groups, not administrative or causal categories.](figures/station_profiles.png)

The principal limitations are observational confounding, omitted emissions/transport and boundary-layer information, nearest-station meteorology, possibly informative completeness filtering, changing pollution levels over time, residual dependence and heavy tails. Four historical years from one city provide limited evidence about new periods or places. Individual intervals and within-station tests do not supply simultaneous protection across the many exploratory analyses.

The core conclusion is methodological: seasonal terms can reduce SSE while residual diagnostics still reveal a deficient model, and classical and robust adjusted tests need not support identical statements. M3 improves average same-day held-out error relative to a simple baseline, yet severely understates high days and can predict negative concentrations. Smaller exploratory errors motivate richer temporal/weather structure; they do not remove the need for a fresh evaluation.

Future work should first secure a genuinely unseen period, prespecify a smaller analysis plan and define covariate availability at the intended prediction time. Sensitivity to missingness and temporal stability deserve priority. No new EWMA, ridge, neural-network or forecasting extension is implemented for this submission.

## 9. Reproducibility, references and assistance

The archive checksum is b04da438b2f331ac0ffd45aebdfec0d20d2367feb5f6948c4b1f7ce1191e33c4. The repository contains the fixed environment lock, chronological configurations, raw provenance, frozen model, dated predictions and source/output hashes. The original Stage 2 protocol is archived byte for byte; its superseded provisional deadline is retained there as historical evidence. Active submission documents use 24 November 2026.

From a fresh checkout, install requirements.lock and the editable package, then run scripts/reproduce.py. Optional requirements-submission.lock and --with-submission rebuild this report and presentation. The independent aggregation and QR/HAC checks do not import the analysis package; extension checks independently reconstruct lags, smearing, logistic optimization, station fits and Ward merges. A separate dense-covariance calculation verifies the calendar-gap sensitivity. Agreement between code paths is computational verification, not new observational evidence.

Numerical claims in this document are read from generated CSV/JSON artifacts and registered with their source rows in build_manifest.json. The report text, PDF slides, editable slides and notes are generated together. Detailed commands, pass/fail results, numerical tolerances and remaining rendering limitations are recorded in reports/stage4_verification.md. Source data are never altered during document generation.

### References

[1] Chen, S. (2017). Beijing Multi-Site Air Quality [Dataset]. UCI Machine Learning Repository. CC BY 4.0. https://doi.org/10.24432/C5RK5G

[2] Duan, N. (1983). Smearing Estimate: A Nonparametric Retransformation Method. Journal of the American Statistical Association, 78(383), 605–610. https://doi.org/10.1080/01621459.1983.10478017

[3] Statsmodels documentation: nested F comparisons, HAC covariance and iterative GLSAR. Method references; empirical results are from this project. https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.RegressionResults.compare_f_test.html

[4] UCI dataset documentation: station coverage, variables and weather matching. https://archive.ics.uci.edu/dataset/501/beijing+multi+site+air+quality+data

Additional method documentation: Bartlett HAC covariance, https://www.statsmodels.org/stable/generated/statsmodels.stats.sandwich_covariance.cov_hac.html ; GLSAR, https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.GLSAR.html .

### AI-assistance disclosure

AI assistance: OpenAI Codex and Anthropic Claude assisted code and drafting; Codex assisted final verification and document preparation. Numerical claims are linked to generated tables and separate implementation checks. These checks are not independent scientific replication. The submitter remains responsible for interpretation and compliance with course policy.

Author and course details are intentionally neutral pending submission metadata. No institutional endorsement or course-specific approval of AI use is implied.
