# Presentation speaker notes

Beyond R²: Seasonal Effects, Residual Dependence, and Model Adequacy in Beijing PM2.5 Regression

Final submission · 24 November 2026

Slides use generated analysis tables. Stage 2 is the prespecified core; Stage 3 and the AR(1) sensitivity are exploratory.

## 1. Beyond R²

Introduce the question as a statistical adequacy investigation, not a forecasting benchmark. The title page is deliberately neutral; no author or course is invented.

## 2. Does season add information beyond weather?

PM2.5 is the daily concentration response. Season may proxy many omitted processes; no causal interpretation is intended. Observed same-day weather defines contemporaneous estimation, not a genuine future forecast.

## 3. A complete calendar and chronological holdouts

UCI has 420,768 hourly station records. There are 1,461 dates and 1,441 eligible Wanliu dates. Each variable's mean uses its own qualified hours. Train-only centering and quantile thresholds prevent future information from entering preprocessing. Local time and rain-amount assumptions are documented.

## 4. Three nested original-scale regressions

Explain nesting and the 3 degrees of freedom per added block. Seasonal terms in M3 compare seasons at the training mean wind; the base wind coefficient is winter's slope. Full rank and numerical conditioning are distinct from statistical precision.

## 5. Classical ANOVA and robust tests differ

Ordinary F assumes appropriate independent, homoscedastic Gaussian errors for exact calibration. HAC uses calendar-separated score pairs and the finite-sample n/(n-p) correction. Its chi-square reference is asymptotic. Fourteen/thirty-day sensitivity results are descriptive, not opportunities to choose a better p-value. Failure to reject does not prove equality.

## 6. R² misses the remaining temporal structure

The lag-one estimate uses 719 pairs of observed adjacent calendar days. Daily aggregation has not made errors independent. Do not interpret the plot as causal evidence or add an iid confidence band. Remaining dynamics motivate cautious inference and later exploratory lag analysis.

## 7. Shape and variance also challenge adequacy

The upper tail departs from a normal reference, and the residual spread is not uniform. Serial, Koenker/Breusch–Pagan and influence diagnostics support this assessment but have calibration assumptions under dependence. Cook's-distance screening identifies 40 M3 points; it does not establish measurement error. All remain in the analysis.

## 8. Average improvement coexists with high-day failure

The fixed validation-MAE rule, including 1% simplicity tolerance, selects M3. M2 is only 1.11% above the minimum. M3 test RMSE is 60.935; baseline RMSE is 73.006. Overall signed error is +15.283, contrasting with high-day underestimation. The training 95th-percentile cutoff is 234.655; no clipping or test-year refit occurred. This frozen evaluation is preserved.

## 9. Exploratory gains on a separate common sample

Every candidate shares dates, so missing-predictor differences do not drive comparisons. Extra weather is dew point plus two wind-vector components. Log estimates use exp(linear predictor) times a training-only smearing factor minus one. That formula does not guarantee nonnegative values. Actual earlier PM2.5 is available to later same-day estimates; the lag never bridges a missing calendar day. Test-year scores are exploratory because the year was already inspected. Compare original-unit MAE, not cross-response R².

## 10. Five short gaps do not reverse the AR(1) sensitivity

Original iterative GLSAR compresses retained rows and bridges five two-day gaps. Compare paired conditional likelihood fits with identical treatment of the first response, changing only row versus calendar spacing. Independent dense covariance calculations verify the coefficients and objective. H1 remains nominally supported, H2 not, including the within-method Holm pair. These exploratory AR-error results do not override the primary Stage 2 HAC/Holm conclusion.

## 11. Wind associations across 12 dependent sites

Each site uses its own eligible dates, centers and cutoff. These are M2 wind coefficients with individual HAC intervals, all below zero. Seasonal results vary. M3 improves test MAE over its station training-mean baseline at 11/12 sites; Gucheng is the exception. Shared weather and pollution mean the estimates are not independent experiments. All cross-station analyses are exploratory.

## 12. High recall comes with many false alarms

Training has 37 positives out of 725 days. The concentration cutoff is 234.655 µg/m³. The probability cutoff maximizes validation F1, with higher-threshold tie breaking; test labels play no part. The default 0.5 catches none of the test high days. Odds-ratio intervals assume independent observations and are exploratory. No clinical or public-health recommendation is made.

## 13. Two groups of training pollutant profiles

The largest merge-height gap for k from 2 to 5 chooses two groups. The lower mean-PM2.5 group contains Changping, Dingling, Huairou, Shunyi. The other group contains the remaining eight stations. Pollutant-specific completeness creates differing eligible date sets. Cluster labels are ordered by mean PM2.5, and do not identify independently validated geographic or risk classes. New-period stability is unknown.

## 14. What the evidence cannot establish

Mention nearest-station weather, emissions/transport and boundary-layer information, which are not modeled here. The period is only four years in one city. A separate numerical implementation is a check on code, not independent scientific replication. No confidence intervals based on independent test days are claimed.

## 15. Conclusions and a defensible next step

Return to the research question: statistical adequacy requires more than fit. Distinguish the chosen model's useful average error improvement from its poor behavior on high days. No new EWMA, ridge, neural-network or forecasting feature was added for submission. Any future confirmation must avoid retuning on the existing test year.

## 16. Sources, reproducibility and assistance

AI assistance: OpenAI Codex and Anthropic Claude assisted code and drafting; Codex assisted final verification and document preparation. Numerical claims are linked to generated tables and separate implementation checks. These checks are not independent scientific replication. The submitter remains responsible for interpretation and compliance with course policy. Full references, exact commands and integrity checks appear in the report and repository. No published model score is presented as our result. Title pages remain neutral pending author/course metadata.
